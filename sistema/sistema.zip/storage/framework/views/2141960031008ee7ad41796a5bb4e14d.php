
<tr>
    <td>
        <select name="items[<?php echo e($index); ?>][medicine_id]" class="form-select form-select-sm">
            <option value="" data-price="0">-- Seleccione --</option>
            <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($medicine->id); ?>" data-price="<?php echo e($medicine->price); ?>"
                    <?php if(($item['medicine_id'] ?? '') == $medicine->id): echo 'selected'; endif; ?>>
                    <?php echo e($medicine->name); ?> (stock: <?php echo e($medicine->stock); ?>)
                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </td>
    <td>
        <input type="number" name="items[<?php echo e($index); ?>][amount]" min="1"
            class="form-control form-control-sm text-center" value="<?php echo e($item['amount'] ?? 1); ?>">
    </td>
    <td class="text-end price">S/ 0.00</td>
    <td class="text-end subtotal">S/ 0.00</td>
    <td class="text-center">
        <button type="button" class="btn btn-sm btn-outline-danger remove-item" title="Quitar">
            <i class="bi bi-trash"></i>
        </button>
    </td>
</tr>
<?php /**PATH C:\Users\DELL\Documents\GitHub\UPSJB_Farmacia\sistema\resources\views/management/sales/item-row.blade.php ENDPATH**/ ?>