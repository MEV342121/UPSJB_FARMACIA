<?php $__env->startSection('title', 'Ventas'); ?>
<?php $__env->startSection('name_section', 'Ventas'); ?>
<?php $__env->startSection('description', 'Detalle de la venta'); ?>
<?php $__env->startSection('item_section', 'Detalle'); ?>
<?php $__env->startSection('route_section', route('sales.index')); ?>
<?php $__env->startSection('section', 'Ventas'); ?>
<?php $__env->startSection('module', 'Gestión'); ?>

<?php $__env->startSection('content'); ?>
<div class="card bg-white border-0 shadow-sm border-5 border-top border-secondary">
    <div class="card-body">
        <?php echo $__env->make('partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="row mb-3">
            <div class="col-12 col-md-4 mb-2">
                <small class="text-muted d-block">Venta Nº</small>
                
                <span class="fw-semibold"><?php echo e(str_pad($sale->id, 6, '0', STR_PAD_LEFT)); ?></span>
            </div>
            <div class="col-12 col-md-4 mb-2">
                <small class="text-muted d-block">Fecha</small>
                <span class="fw-semibold"><?php echo e($sale->date->format('d/m/Y H:i')); ?></span>
            </div>
            <div class="col-12 col-md-4 mb-2">
                <small class="text-muted d-block">Vendedor</small>
                <span class="fw-semibold"><?php echo e($sale->user->name); ?></span>
            </div>
            <div class="col-12 col-md-4 mb-2">
                <small class="text-muted d-block">Cliente</small>
                <span class="fw-semibold"><?php echo e($sale->customer->name); ?></span>
            </div>
            <div class="col-12 col-md-4 mb-2">
                <small class="text-muted d-block">DNI</small>
                <span class="fw-semibold"><?php echo e($sale->customer->dni); ?></span>
            </div>
        </div>

        <table class="table table-sm align-middle">
            <thead>
                <tr>
                    <th class="small text-uppercase text-center">Nº</th>
                    <th class="small text-uppercase">Medicamento</th>
                    <th class="small text-uppercase text-center">Cantidad</th>
                    <th class="small text-uppercase text-end">Precio unit.</th>
                    <th class="small text-uppercase text-end">Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $sale->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($detail->medicine->name); ?></td>
                    <td class="text-center"><?php echo e($detail->amount); ?></td>
                    <td class="text-end">S/ <?php echo e(number_format($detail->price_unit, 2)); ?></td>
                    <td class="text-end">S/ <?php echo e(number_format($detail->subtotal, 2)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    
                    <td colspan="4" class="text-end">Op. gravada</td>
                    <td class="text-end">S/ <?php echo e(number_format($sale->total - $sale->igv, 2)); ?></td>
                </tr>
                <tr>
                    <td colspan="4" class="text-end">IGV (18%)</td>
                    <td class="text-end">S/ <?php echo e(number_format($sale->igv, 2)); ?></td>
                </tr>
                <tr>
                    <td colspan="4" class="text-end fw-semibold">Total</td>
                    <td class="text-end fw-bold">S/ <?php echo e(number_format($sale->total, 2)); ?></td>
                </tr>
            </tfoot>
        </table>

        <a href="<?php echo e(route('sales.index')); ?>" class="btn btn-secondary">Volver</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.administrador', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DELL\Documents\GitHub\UPSJB_Farmacia\sistema\resources\views/management/sales/show.blade.php ENDPATH**/ ?>