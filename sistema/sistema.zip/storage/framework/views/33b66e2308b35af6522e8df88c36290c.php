<?php $__env->startSection('title', 'Medicamentos'); ?>
<?php $__env->startSection('name_section', 'Medicamentos'); ?>
<?php $__env->startSection('description', 'Listado de registros de medicamentos'); ?>
<?php $__env->startSection('item_section', 'Inicio'); ?>
<?php $__env->startSection('route_section', route('medicines.index')); ?>
<?php $__env->startSection('section', 'Medicamentos'); ?>
<?php $__env->startSection('module', 'Gestión'); ?>

<?php $__env->startSection('content'); ?>
<div class="card bg-white border-0 shadow-sm border-5 border-top border-secondary">
    <div class="card-header bg-white">
        <div class="row">
            <div class="col-12 col-md-3 mb-2 mb-md-0">
                <a href="<?php echo e(route('medicines.create')); ?>" class="btn btn-primary rounded-3 text-uppercase text-white w-100">
                    <i class="bi bi-plus-lg me-2"></i><span class="small fw-medium">Nuevo registro</span>
                </a>
            </div>

            
            <div class="col-12 col-md-9">
                <form action="<?php echo e(route('medicines.index')); ?>" method="GET" class="row g-2 align-items-center">
                    <div class="col-12 col-md-4">
                        <input type="text" name="search" class="form-control" placeholder="Buscar por nombre"
                            value="<?php echo e(request('search')); ?>">
                    </div>
                    <div class="col-12 col-md-3">
                        <select name="category_id" class="form-select">
                            <option value="">Todas las categorías</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php if(request('category_id') == $category->id): echo 'selected'; endif; ?>>
                                    <?php echo e($category->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-6 col-md-2">
                        <div class="form-check">
                            <input type="checkbox" name="low_stock" value="1" id="low_stock" class="form-check-input"
                                <?php if(request('low_stock')): echo 'checked'; endif; ?>>
                            <label for="low_stock" class="form-check-label small">Stock bajo</label>
                        </div>
                    </div>
                    <div class="col-6 col-md-3 d-flex gap-1">
                        <button type="submit" class="btn btn-outline-primary w-100" title="Filtrar"><i class="bi bi-search"></i></button>
                        <a href="<?php echo e(route('medicines.index')); ?>" class="btn btn-outline-secondary w-100" title="Limpiar filtros"><i class="bi bi-x-lg"></i></a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="card-body">
        
        <?php echo $__env->make('partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <h6 class="text-uppercase small text-muted mb-3">Total de registros encontrados: <?php echo e($medicines->count()); ?></h6>
        <table id="display" class="table table-sm table-hover w-100 bg-white">
            <thead>
                <tr>
                    <th class="text-center align-middle text-uppercase small">Nº</th>
                    <th class="text-center align-middle text-uppercase small">Imagen</th>
                    <th class="text-center align-middle text-uppercase small">Nombre</th>
                    <th class="text-center align-middle text-uppercase small">Categoría</th>
                    <th class="text-center align-middle text-uppercase small">Precio</th>
                    <th class="text-center align-middle text-uppercase small">Stock</th>
                    <th class="text-center align-middle text-uppercase small">Acciones</th>
                </tr>
            </thead>
            <tbody>
                
                <?php $__empty_1 = true; $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-center align-middle"><?php echo e($loop->iteration); ?> </td>
                    <td class="text-center align-middle">
                        <?php if($medicine->image): ?>
                            <img src="<?php echo e(asset('storage/' . $medicine->image)); ?>" alt="<?php echo e($medicine->name); ?>"
                                class="rounded" style="width: 48px; height: 48px; object-fit: cover">
                        <?php else: ?>
                            <i class="bi bi-image text-muted fs-4"></i>
                        <?php endif; ?>
                    </td>
                    <td class="text-start align-middle"><?php echo e($medicine->name); ?></td>
                    
                    <td class="text-center align-middle"><?php echo e($medicine->category->name); ?></td>
                    <td class="text-end align-middle">S/ <?php echo e(number_format($medicine->price, 2)); ?></td>
                    <td class="text-center align-middle">
                        
                        <span class="badge <?php echo e($medicine->stock <= $lowStock ? 'bg-danger' : 'bg-success'); ?>"><?php echo e($medicine->stock); ?></span>
                    </td>
                    <td class="text-center align-middle">
                        <div class="dropdown">
                            <button class="btn btn-light" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="bi bi-three-dots-vertical"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="<?php echo e(route('medicines.edit', $medicine)); ?>">Editar</a></li>
                                <li>
                                    <form action="<?php echo e(route('medicines.destroy', $medicine)); ?>" method="POST"
                                        onsubmit="return confirm('¿Seguro que desea eliminar este medicamento?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?> 
                                        <button type="submit" class="dropdown-item text-danger">Eliminar</button>
                                    </form>
                                </li>
                            </ul>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center text-muted py-3">No se encontraron medicamentos</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.administrador', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DELL\Documents\GitHub\UPSJB_Farmacia\sistema\resources\views/management/medicines/index.blade.php ENDPATH**/ ?>