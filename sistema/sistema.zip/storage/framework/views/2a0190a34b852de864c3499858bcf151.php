

<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('name_section', 'Dashboard'); ?>
<?php $__env->startSection('description', 'Resumen de estadísticas'); ?>
<?php $__env->startSection('item_section', 'Inicio'); ?>
<?php $__env->startSection('section', 'Dashboard'); ?>
<?php $__env->startSection('module', 'Principal'); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.administrador', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DELL\Documents\GitHub\UPSJB_Farmacia\sistema\resources\views/principal/dashboard/index.blade.php ENDPATH**/ ?>