<?php $__env->startSection('title', 'Usuarios'); ?>
<?php $__env->startSection('name_section', 'Usuarios'); ?>
<?php $__env->startSection('description', 'Listado de registros de usuarios'); ?>
<?php $__env->startSection('item_section', 'Inicio'); ?>
<?php $__env->startSection('route_section', route('users.index')); ?>
<?php $__env->startSection('section', 'Usuarios'); ?>
<?php $__env->startSection('module', 'Configuraciones'); ?>

<?php $__env->startSection('content'); ?>
<div class="card bg-white border-0 shadow-sm border-5 border-top border-secondary">
    <div class="card-header bg-white">
        <div class="row">
            <div class="col-12 col-md-3">
                <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary rounded-3 text-uppercase text-white w-100">
                    <i class="bi bi-plus-lg me-2"></i><span class="small fw-medium">Nuevo registro</span>
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">
        
        <?php echo $__env->make('partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <h6 class="text-uppercase small text-muted mb-3">Total de registros encontrados: <?php echo e($users->count()); ?></h6>
        <table id="display" class="table table-sm table-hover w-100 bg-white">
            <thead>
                <tr>
                    <th class="text-center align-middle text-uppercase small">Nº</th>
                    <th class="text-center align-middle text-uppercase small">Nombre</th>
                    <th class="text-center align-middle text-uppercase small">DNI</th>
                    <th class="text-center align-middle text-uppercase small">Correo</th>
                    <th class="text-center align-middle text-uppercase small">Teléfono</th>
                    <th class="text-center align-middle text-uppercase small">Rol</th>
                    <th class="text-center align-middle text-uppercase small">Acciones</th>
                </tr>
            </thead>
            <tbody>
                
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-center align-middle"><?php echo e($loop->iteration); ?> </td>
                    <td class="text-start align-middle"><?php echo e($user->name); ?></td>
                    <td class="text-center align-middle"><?php echo e($user->dni); ?></td>
                    <td class="text-start align-middle"><?php echo e($user->email); ?></td>
                    <td class="text-center align-middle"><?php echo e($user->phone ?? '—'); ?></td>
                    <td class="text-center align-middle"><?php echo e($user->role->name); ?></td>
                    <td class="text-center align-middle">
                        <div class="dropdown">
                            <button class="btn btn-light" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="bi bi-three-dots-vertical"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="<?php echo e(route('users.edit', $user)); ?>">Editar</a></li>
                                <li>
                                    <form action="<?php echo e(route('users.destroy', $user)); ?>" method="POST"
                                        onsubmit="return confirm('¿Seguro que desea eliminar este usuario?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?> 
                                        <button type="submit" class="dropdown-item text-danger">Eliminar</button>
                                    </form>
                                </li>
                            </ul>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center text-muted py-3">No hay usuarios registrados</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.administrador', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DELL\Documents\GitHub\UPSJB_Farmacia\sistema\resources\views/settings/users/index.blade.php ENDPATH**/ ?>