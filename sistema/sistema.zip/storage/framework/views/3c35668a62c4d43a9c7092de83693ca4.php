<?php $__env->startSection('title', 'Clientes'); ?>
<?php $__env->startSection('name_section', 'Clientes'); ?>
<?php $__env->startSection('description', 'Nuevo registro de cliente'); ?>
<?php $__env->startSection('item_section', 'Nuevo'); ?>
<?php $__env->startSection('route_section', route('customers.index')); ?>
<?php $__env->startSection('section', 'Clientes'); ?>
<?php $__env->startSection('module', 'Gestión'); ?>

<?php $__env->startSection('content'); ?>
<div class="card bg-white border-0 shadow-sm border-5 border-top border-secondary">
    <div class="card-body">
        <form action="<?php echo e(route('customers.store')); ?>" method="POST"> 
            <?php echo csrf_field(); ?> 
            <?php echo $__env->make('management.customers.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> 
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.administrador', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DELL\Documents\GitHub\UPSJB_Farmacia\sistema\resources\views/management/customers/create.blade.php ENDPATH**/ ?>