<?php $__env->startSection('title', 'Medicamentos'); ?>
<?php $__env->startSection('name_section', 'Medicamentos'); ?>
<?php $__env->startSection('description', 'Editar registro de medicamento'); ?>
<?php $__env->startSection('item_section', 'Editar'); ?>
<?php $__env->startSection('route_section', route('medicines.index')); ?>
<?php $__env->startSection('section', 'Medicamentos'); ?>
<?php $__env->startSection('module', 'Gestión'); ?>

<?php $__env->startSection('content'); ?>
<div class="card bg-white border-0 shadow-sm border-5 border-top border-secondary">
    <div class="card-body">
        <form action="<?php echo e(route('medicines.update', $medicine)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?> 
            <?php echo method_field('PUT'); ?> 
            <?php echo $__env->make('management.medicines.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> 
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.administrador', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DELL\Documents\GitHub\UPSJB_Farmacia\sistema\resources\views/management/medicines/edit.blade.php ENDPATH**/ ?>